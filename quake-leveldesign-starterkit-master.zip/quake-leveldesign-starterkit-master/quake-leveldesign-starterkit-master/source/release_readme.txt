**************************************************
The Original Quake Map Sources
by id Software (C) 1996
Released October 2006 during Quake's 10th Anniversary
**************************************************

These are the original Quake map source files as of Quake v1.06.  I've included the chopped-off
beginning to E2M6 (The Dismal Oubliette) as well, named E2M10.MAP.  The majority of these maps
were created during the last 7 months of Quake's development cycle when we had decided on the
final direction of the game.  For a comprehensive listing of each map, its name, author and
place in the final game please visit the Wikipedia (http://en.wikipedia.org/wiki/Quake).

Also included with the full map sources are the map sources created for the game's items (armor,
ammo, etc.) which were needed to light the BSP files so the items could be viewed in the game.

You can open these .MAP files with a Quake map editor such as Qoole 99.

Have fun and Happy Birthday, Quake!


John Romero
john@rome.ro
http://rome.ro

These map sources are released under the terms of the GPL (http://www.fsf.org/licensing/licenses/gpl.html).
See the accompanying gnu.txt for details.